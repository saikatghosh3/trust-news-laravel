<?php

return [
    'name' => 'AutoPost'
];
