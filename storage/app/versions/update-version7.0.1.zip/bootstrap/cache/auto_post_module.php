<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\AutoPost\\Providers\\AutoPostServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\AutoPost\\Providers\\AutoPostServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);